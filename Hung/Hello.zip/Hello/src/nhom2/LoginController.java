/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nhom2;


import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.naming.spi.DirStateFactory;

/**
 *
 * @author Thanh Dien
 */
public class LoginController implements Initializable {
    DatabaseConn db = new DatabaseConn();
    String sql;
    int role;
   
    @FXML
    private TextField txtUser;
    
    @FXML 
    private PasswordField txtPass;
    
    @FXML private Button btnLogin, btnExit;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    
    
    @FXML
    public void Exit(ActionEvent event) {
        System.exit(0);   
    }
    
    @FXML
    public void Login(ActionEvent event) throws SQLException, IOException{
        boolean check = false;
        String user = txtUser.getText();
        String pass = txtPass.getText();
        sql = "select * from Account";
        db.rs = db.stmt.executeQuery(sql);
        while(db.rs.next()){
            if (user.equalsIgnoreCase(db.rs.getString("Username"))){
                if (pass.equalsIgnoreCase(db.rs.getString("Password"))){
                    check = true;
                    role = db.rs.getInt("Role");
                    break;
                }
            }
        }
        
        
        if (check){
            System.out.println("Login Successful!");
            AccountController ac = new AccountController();
            Stage stage = new Stage();
            stage.setTitle("Add Model");
            stage.setScene(new Scene(ac));
            stage.show();
            
            final Node source = (Node) event.getSource();
            final Stage stage1 = (Stage) source.getScene().getWindow();
            stage1.close();
            
        } else { 
            System.out.println("Wrong!");
            Alert alert = new Alert(AlertType.ERROR, "Wrong Username or Password! Please re-enter!");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                txtUser.setText("");
                txtPass.setText("");
            }
        }
    }
    
}
