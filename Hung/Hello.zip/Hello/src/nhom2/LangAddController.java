/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nhom2;

import java.io.IOException;
import java.net.URL;
import java.util.Observable;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Jonathan
 */
public class LangAddController implements Initializable {
    
    ObservableList item;
    ObservableList item1;
    int i = 0;
    String ownSkill;
    
    @FXML
    private Button btnNext, btnPrev, btnSave, btnExit, btnAdd;
    
    @FXML
    public ListView listSkill, listSkill1;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        item = FXCollections.observableArrayList("English", "Chinese", "Japanese");
        item1 = FXCollections.observableArrayList();
        listSkill.setItems(item);
        listSkill.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        listSkill1.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

    }

    public void next(ActionEvent event){
        
        item1.addAll(listSkill.getSelectionModel().getSelectedItem().toString());
        listSkill1.setItems(item1);
        
        item.remove(listSkill.getSelectionModel().getSelectedIndex());
        listSkill.setItems(item);
    }
    
    @FXML
    public void prev(ActionEvent event){
        item.addAll(listSkill1.getSelectionModel().getSelectedItem().toString());
        listSkill.setItems(item);
        
        item1.remove(listSkill1.getSelectionModel().getSelectedIndex());
        listSkill1.setItems(item1);
    }
    
    @FXML
    public void add(ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("SkillCreate.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Create Skill!");
        stage.show();
        
        
        
    }
    
    @FXML
    public void save(ActionEvent event){
        
    }
    
    @FXML
    public void Exit(ActionEvent event){
        Stage stage = (Stage) btnExit.getScene().getWindow();
        stage.close();
        
    }
}
