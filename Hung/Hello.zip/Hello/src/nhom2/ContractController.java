/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nhom2;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import java.util.TreeMap;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Bill
 */
public class ContractController implements Initializable {
    DatabaseConn db = new DatabaseConn();
  
    @FXML private Button btnAdd, btnEdit, btnDel, btnN, btnY;
    
    @FXML private TextField searchBar, contractId, customerName, file, contractAddress;

    @FXML private DatePicker dateStart, dateEnd, dateSign;

    @FXML private TableView<Contract> tbContract;
    @FXML private TableView tbModel;
    @FXML private TableColumn<Contract, Integer> colID;
    @FXML private TableColumn<Contract, String> colName;
    @FXML private TableColumn<Contract, DatePicker> colStart;
    @FXML private TableColumn<Contract, DatePicker> colEnd;
    @FXML private AnchorPane viewInfo;
    TreeMap map1, map2;
    
    ObservableList list = FXCollections.observableArrayList();
    public ContractController() {
    }
  
    public class Contract {
        private int ID;
        private String name, file, addr ;
        private Date start, end, sign;
        //private LocalDate date;
        
        public Contract (int ID, String name, Date start, Date end, Date sign, String addr, String file){
            this.ID = ID;
            this.name = name;
            this.end = end;
            this.start = start;
            this.sign = sign;
            this.addr = addr;
            this.file = file;
        }
        
        /**
         * @return the ID
         */
        public int getID() {
            return ID;
        }

        /**
         * @param ID the ID to set
         */
        public void setID(int ID) {
            this.ID = ID;
        }

        /**
         * @return the name
         */
        public String getName() {
            return name;
        }

        /**
         * @param name the name to set
         */
        public void setName(String name) {
            this.name = name;
        }

        /**
         * @return the start
         */
        public Date getStart() {
            return start;
        }

        /**
         * @param start the start to set
         */
        public void setStart(Date start) {
            this.start = start;
        }

        /**
         * @return the end
         */
        public Date getEnd() {
            return end;
        }

        /**
         * @param end the end to set
         */
        public void setEnd(Date end) {
            this.end = end;
        }

        /**
         * @return the sign
         */
        public Date getSign() {
            return sign;
        }

        /**
         * @param sign the sign to set
         */
        public void setSign(Date sign) {
            this.sign = sign;
        }

        /**
         * @return the file
         */
        public String getFile() {
            return file;
        }

        /**
         * @param file the file to set
         */
        public void setFile(String file) {
            this.file = file;
        }

        /**
         * @return the address
         */
        public String getAddr() {
            return addr;
        }

        /**
         * @param addr the address to set
         */
        public void setAddr(String addr) {
            this.addr = addr;
        }
    }
    
    String sql;
    ObservableList listContract = FXCollections.observableArrayList();
    ObservableList listModel = FXCollections.observableArrayList();
    
    @FXML
    public void setTable(){
        try {
            
            sql = "select * from Contract";
            db.rs = db.stmt.executeQuery(sql);

            while(db.rs.next()){
                int Id = db.rs.getInt("ContractID");
                String name = db.rs.getString("ConName");
                String file = db.rs.getString("ConFile");
                String addr = db.rs.getString("ConAddr");
                Date start = db.rs.getDate("ConStart");
                Date end = db.rs.getDate("ConEnd");
                Date sign = db.rs.getDate("ConSignDate");
                Contract contract = new Contract(Id, name, start, end, sign, file, addr);
                listContract.add(contract);
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        colID.setCellValueFactory(new PropertyValueFactory<>("ID"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colStart.setCellValueFactory(new PropertyValueFactory<>("start"));
        colEnd.setCellValueFactory(new PropertyValueFactory<>("end"));
        
        tbContract.setItems(listContract);
    }
    public void getTableData(){
        tbContract.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent me) {
                Contract Con = tbContract.getSelectionModel().getSelectedItem();
                if (Con != null){
                    LocalDate date = null;
                    btnEdit.setDisable(false);
                    btnDel.setDisable(false);
                    contractId.setText(String.valueOf(Con.getID()));
                    customerName.setText(Con.getName());
                    file.setText(Con.getFile());
                    contractAddress.setText(Con.getAddr());
                    Date sign = Con.getSign();
                    Date start = Con.getStart();
                    Date end = Con.getEnd();
                    

                }
            }


        });
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnN.setVisible(false);
        btnY.setVisible(false);
        btnEdit.setDisable(true);
        btnDel.setDisable(true);
        setTable();
        getTableData();
    }
    
    public void Cancle(MouseEvent event){
        btnN.setVisible(false);
        btnY.setVisible(false);
        contractId.setDisable(true);
        customerName.setDisable(true);
        file.setDisable(true);
        dateStart.setDisable(true);
        dateEnd.setDisable(true);
        dateSign.setDisable(true);
        contractAddress.setDisable(true);
    }
    
    public void Add(MouseEvent event){
        btnN.setVisible(true);
        btnY.setVisible(true);
        contractId.setDisable(false);
        customerName.setDisable(false);
        file.setDisable(false);
        dateStart.setDisable(false);
        dateEnd.setDisable(false);
        dateSign.setDisable(false);
        contractAddress.setDisable(false);
    }
    
    public void Edit(MouseEvent event){
        btnN.setVisible(true);
        btnY.setVisible(true);
        contractAddress.setDisable(false);
        customerName.setDisable(false);
        file.setDisable(false);
        dateStart.setDisable(false);
        dateEnd.setDisable(false);
    }
    
    public void Delete(MouseEvent event){
        btnN.setVisible(true);
        btnY.setVisible(true);
    }
    
    public void viewInformation(MouseEvent event){
        viewInfo.setVisible(true);
    }
    
    public void Save(ActionEvent event) throws SQLException{
        
        //Add to SQL
        String CusName = customerName.getText();
        String ConAddr = customerName.getText();
        String ConFile = file.getText();
        LocalDate ConSignDate = dateSign.getValue();
        LocalDate ConStart = dateStart.getValue();
        LocalDate ConEnd = dateEnd.getValue();
        sql = "insert into Account values ('"+CusName+"','"+ConFile+"','"+ConFile+"','"+ConAddr+"','"+ConSignDate+"','"+ConStart+"','"+ConEnd+"')";
        db.stmt.executeUpdate(sql);
        setTable();
    }
    

}
