/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nhom2;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Observable;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Jonathan
 */
public class AccountController extends AnchorPane implements Initializable {
    DatabaseConn db = new DatabaseConn();
    
    @FXML TableView table;
    
    @FXML TableColumn colId, colUsername, colRole, colCity;
    
    @FXML TextField txtId, txtUsername;
    
    @FXML PasswordField txtPass;
    
    @FXML RadioButton rdoAdmin, rdoManager;
    
    @FXML ComboBox cboCity;
    
    @FXML Button btnAdd, btnEdit, btnDel;
    
    @FXML Pane AddAccount, accountPane;
        
    @FXML RadioButton rdoMan1, rdoAdmin1;
    
    @FXML TextField txtUsername1;
    
    @FXML PasswordField txtPass1, txtRePass1;
    
    @FXML ComboBox cboCity1;
    
    @FXML AnchorPane root1;
    
    TreeMap map1;

    public AccountController() {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Account.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();            
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }
    
    
    public class Account {
        int id;
        String user, pass, role, city;


        public Account(int id, String user, String pass, String role, String city) {
            this.id = id;
            this.user = user;
            this.pass = pass;
            this.role = role;
            this.city = city;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getUser() {
            return user;
        }

        public void setUser(String user) {
            this.user = user;
        }

        public String getPass() {
            return pass;
        }

        public void setPass(String pass) {
            this.pass = pass;
        }

        public String getRole() {
            return role;
        }

        public void setRole(String role) {
            this.role = role;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }
        
        
    }
    
    
    String sql;
    ObservableList listCombo = FXCollections.observableArrayList();
    ObservableList listTable = FXCollections.observableArrayList();
    
    
    public void setTable(){
        try {
            
            sql = "select Account.*, City.City from Account, City where Account.CityID = City.CityID";
            db.rs = db.stmt.executeQuery(sql);

            while(db.rs.next()){
                int id = db.rs.getInt("AccountID");
                String user = db.rs.getString("Username");
                String pass = db.rs.getString("Password");
                String role = "Admin";
                if (db.rs.getInt("Role") == 2){
                    role = "Manager";
                }
                String city = db.rs.getString("City");
                
                
                Account acc = new Account(id, user, pass, role, city);
                listTable.add(acc);
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colUsername.setCellValueFactory(new PropertyValueFactory<>("user"));
        colRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        colCity.setCellValueFactory(new PropertyValueFactory<>("city"));
        
        table.setItems(listTable);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
        //ComboBox
        ObservableList list = FXCollections.observableArrayList();
        map1 = new TreeMap();
        
        try {
            sql = "select * from City";
            db.rs = db.stmt.executeQuery(sql);
            while(db.rs.next()){
                list.add(db.rs.getString("City"));
                map1.put(db.rs.getString("City"), db.rs.getInt("CityID"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        cboCity1.setItems(list);
        System.out.println(map1.get("Ha Noi"));
        
        //RadioButton
        ToggleGroup group = new ToggleGroup();
        rdoMan1.setToggleGroup(group);
        rdoMan1.setSelected(true);
        rdoAdmin1.setToggleGroup(group);
        
        //ComboBox
        try {
            sql = "select * from City";
            db.rs = db.stmt.executeQuery(sql);
            while(db.rs.next()){
                listCombo.add(db.rs.getString("City"));
            }
        } catch (SQLException ex) {
           ex.printStackTrace();
        }
        cboCity.setItems(listCombo);

        
        //TableView
        
        
        setTable();
        
        //RadioButton
        ToggleGroup group1 = new ToggleGroup();
        rdoAdmin.setToggleGroup(group1);
        rdoManager.setToggleGroup(group1);
        
    }
    
    
    @FXML
    public void mouseClicked(MouseEvent event){
        int id;
        String username;
        String role;
        String city;
        String pass;
        
        TablePosition pos = (TablePosition) table.getSelectionModel().getSelectedCells().get(0);
        int row = pos.getRow();
        
        Account item = (Account) table.getItems().get(row);
        
        id = item.id;
        username = item.user;
        role = item.role;
        city = item.city;
        pass = item.pass;
        
        txtId.setText(String.valueOf(id));
        txtUsername.setText(username);
        txtPass.setText(pass);
        
        for (int i = 0; i < listCombo.size(); i++) {
            if(city.equalsIgnoreCase((String) listCombo.get(i))){
                cboCity.getSelectionModel().select(i);
                break;
            }
        }
        
        if(role.equalsIgnoreCase("Admin")){
            rdoAdmin.setSelected(true);
        }else {
            rdoManager.setSelected(true);
        }
    }
    
    
    
    public void Add(ActionEvent event) throws IOException{
        
        AddAccount.setVisible(true);
        accountPane.setDisable(true);
        AddAccount.setDisable(false);
    }
    
    public void Back(ActionEvent event){
        AddAccount.setVisible(false);
        accountPane.setDisable(false);
    }
    
    public void Save(ActionEvent event) throws SQLException{
        
        //ErrorHandler
        /*if(txtUsername.getText().length()==0){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Username cannot be blank!");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                txtUsername.focusTraversableProperty();
            }
        }*/
        
        
        //Add to SQL
        String username = txtUsername1.getText();
        String pass = txtPass1.getText();
        String repass = txtRePass1.getText();
        int role = 1;
        if(rdoMan1.isSelected()){
            role = 2;
        }
        String city = (String) cboCity1.getSelectionModel().getSelectedItem();
        
        int cityid = (int) map1.get(city);
        
        sql = "insert into Account values ('"+username+"','"+pass+"',"+role+","+cityid+")";
        db.stmt.executeUpdate(sql);
        
        AddAccount.setVisible(false);
        accountPane.setDisable(false);
        table.getItems().clear();
        setTable();
        

    }
        
    }
