/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nhom2;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Observable;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javax.swing.JOptionPane;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 *
 * @author Jonathan
 */
public class ModelAddController implements Initializable {
    DatabaseConn db;
    String sql, url;
    String name, city, body, skill;
    int age;
    int available = 0;
    final FileChooser fileChooser = new FileChooser();
    
    @FXML
    private Button btnCancle, btnSave, btnAddSkill, btnAddCity, btnImg;
    @FXML
    private ComboBox<String> cboCity;
    @FXML
    private TextField txtName, txtAge, txtBody1, txtBody2, txtBody3;
    @FXML
    private TextArea txaSkill;
    @FXML
    private RadioButton rdoAvailable;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cboCity.getItems().setAll("Ha Noi", "Hai Phong", "Sai Gon");
        cboCity.getSelectionModel().select(0);
        //db = new DatabaseConn();
    }    

    @FXML
    public void cancle(ActionEvent event){
        System.exit(0);
    }
    
    @FXML
    public void saveModel(ActionEvent event){
        /*name = txtName.getText();
        age = Integer.parseInt(txtAge.getText());
        city = cboCity.getValue();
        body = txtBody1.getText()+" - "+txtBody2.getText()+" - "+txtBody3.getText();
        skill = txaSkill.getText();
        
        if (rdoAvailable.isSelected()){
            available = 1;
        }
        
        try {
            sql = "Insert into Model(ModelName, Age, City, Body, Availability) values('"+name+"', "+age+", '"+city+"', '"+body+"', "+available+")";
            db.rs = db.stmt.executeQuery(sql);
            System.out.println("Add succesfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }*/
    }
    
    
    
    public void skillAdd(ActionEvent event) throws IOException{
        System.out.println("hehe");
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("SkillAdd.fxml"));
        Parent root = fxmlLoader.load();
        
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setTitle("Add Skill");
        stage.setScene(scene);
        stage.show();
    }
    
    public void languageAdd(ActionEvent event) throws IOException{
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("LangAdd.fxml"));
        Parent root = fxmlLoader.load();
        
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setTitle("Add Skill");
        stage.setScene(scene);
        stage.show();
    }
    
    public void addImg(ActionEvent even){
          
    }
    
}
