/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nhom2;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.Action;

/**
 * FXML Controller class
 *
 * @author Jonathan
 */
public class LangCreateController implements Initializable {
    public String skill;
    SkillAddController objSkill;
    
    @FXML
    private Button btnOk, btnBack;
    
    @FXML
    private TextField txtSkill;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    public void OK(ActionEvent event){
        skill = txtSkill.getText();
        
        Stage stage = (Stage) btnBack.getScene().getWindow();
        stage.close();
    }
    
    @FXML
    public void Back(ActionEvent event){
        Stage stage = (Stage) btnBack.getScene().getWindow();
        stage.close();
    }
    
}
