/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nhom2;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Observable;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Jonathan
 */
public class AccountAddController extends AnchorPane implements Initializable {
    DatabaseConn db = new DatabaseConn();
    String sql;
    
    @FXML
    RadioButton rdoMan, rdoAdmin;
    
    @FXML TextField txtUsername1;
    
    @FXML PasswordField txtPass1, txtRePass1;
    
    @FXML ComboBox cboCity;
    
    TreeMap map1;

    public AccountAddController(int controlTable) {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AccountAdd.fxml"));
        fxmlLoader.setRoot(this);
        fxmlLoader.setController(this);
        try {
            fxmlLoader.load();            
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }

    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //ComboBox
        ObservableList list = FXCollections.observableArrayList();
        map1 = new TreeMap();
        
        try {
            sql = "select * from City";
            db.rs = db.stmt.executeQuery(sql);
            while(db.rs.next()){
                list.add(db.rs.getString("City"));
                map1.put(db.rs.getString("City"), db.rs.getInt("CityID"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        cboCity.setItems(list);
        //RadioButton
        ToggleGroup group = new ToggleGroup();
        rdoMan.setToggleGroup(group);
        rdoMan.setSelected(true);
        rdoAdmin.setToggleGroup(group);
    }

    public void Back(ActionEvent event){
        final Node source = (Node) event.getSource();
        final Stage stage1 = (Stage) source.getScene().getWindow();
        stage1.close();
    }
    
    public void Save(ActionEvent event) throws SQLException{
        
        //ErrorHandler
        /*if(txtUsername.getText().length()==0){
            Alert alert = new Alert(Alert.AlertType.ERROR, "Username cannot be blank!");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                txtUsername.focusTraversableProperty();
            }
        }*/
        
        //Add to SQL
        String username = txtUsername1.getText();
        String pass = txtPass1.getText();
        String repass = txtRePass1.getText();
        int role = 1;
        if(rdoMan.isSelected()){
            role = 2;
        }
        String city = (String) cboCity.getSelectionModel().getSelectedItem();
        int cityid = (int) map1.get(city);
        
        sql = "insert into Account values ('"+username+"','"+pass+"',"+role+","+cityid+")";
        db.stmt.executeUpdate(sql);
        
        
        
        final Node source = (Node) event.getSource();
        final Stage stage1 = (Stage) source.getScene().getWindow();
        stage1.close();
        
    
    }
    
}
